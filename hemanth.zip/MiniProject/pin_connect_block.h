#include "types.h"

void cfgPortPinFunc(u32 PortNo,u32 PinNo,u32 PinFunc);
