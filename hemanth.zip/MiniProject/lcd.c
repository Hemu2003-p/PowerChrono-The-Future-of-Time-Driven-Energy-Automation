# include "types.h"
#include<LPC21xx.h>
#include "defines.h"
#include "lcd_defines.h"
#include "delay.h"
#include "lcd.h"

void WriteLCD(u8 byte)
{
//	#if LCD_MODE==8
	IOCLR0=1<<LCD_RW;
	WRITEBYTE(IOPIN0,LCD_DATA,byte);
	delay_ms(1);
	IOSET0=1<<LCD_EN;
	delay_us(1);
	IOCLR0=1<<LCD_EN;
	delay_ms(2);
}
void CmdLCD(u8 CmdByte)
{
	IOCLR0=1<<LCD_RS;
	WriteLCD(CmdByte);
}
void InitLCD(void)
{
	IODIR0|=((0xFF<<LCD_DATA)|(1<<LCD_RS)|(1<<LCD_RW)|(1<<LCD_EN));
	delay_ms(15);
	CmdLCD(0x30);
	delay_ms(4);
	delay_us(100);
	CmdLCD(0x30);
	delay_us(100);
	CmdLCD(MODE_8BIT_1LINE);
	CmdLCD(MODE_8BIT_2LINE);
	CmdLCD(DSP_ON_CUR_BLINK);
	CmdLCD(CLEAR_LCD);
	CmdLCD(SHIFT_CUR_RIGHT);
}

void CharLCD(u8 asciival)
{
	IOSET0=1<<LCD_RS;
	WriteLCD(asciival);
}
void StrLCD(s8 *s)
{
	while(*s)
	CharLCD(*s++);
}
void U32LCD(u32 n)
{
	s32 i=0;
	u8 a[10];
	if(n==0)
	{
		CharLCD('0');
	}
	else
	{
		while(n>0)
		{
			a[i++]=(n%10)+48;
			n/=10;
		}
		for(--i;i>=0;i--)
		CharLCD(a[i]);
	}
}
void S32LCD(s32 n)
{
	if(n<0)
	{
		CharLCD('-');
		n=-n;
	}
	U32LCD(n);
}
void F32LCD(f32 fn,u8 nDP)
{
	u32 n,i;
	if(fn<0.0)
	{
		CharLCD('-');
		fn=-fn;
	}
	n=fn;
	U32LCD(n);
	CharLCD('.');
	for(i=0;i<nDP;i++)
	{
		fn=(fn-n)*10;
		n=fn;
		CharLCD(n+48);
	}
}
void BuildCGRAM(u8 *p,u8 nBytes)
{
	u32 i;
	CmdLCD(GOTO_CGRAM_START);
	IOSET0=1<<LCD_RS;
	for(i=0;i<nBytes;i++)
	{
		WriteLCD(p[i]);
	}
	CmdLCD(GOTO_LINE1_POS0);
}
