/********  Mini Project ********/
#include <LPC21xx.h>
#include "mini_project.h"

//defining the device pin
#define DEVICE_PIN 5//p0.5
//defining the on and off switch pin
#define ON_OFF_SW 6//P0.6

// Declaring Variables
s8 on_hrs,on_min,off_hrs,off_min;
u32 dow,day,date,year,month,menu;
u32 hour,minute,second,num,lastkey;
u8 keyV;
u32 flag=0;
//Array for weeks 
extern s8 week[][4];
//array for Bulb on and off 
u8 BulbONOFF[]={0x00,0x0E,0x11,0x11,0x0E,0x0E,0x1F,0x00,
              0x00,0x0E,0x1F,0x1F,0x0E,0x0E,0x1F,0x00};

int main()
{
	//Initialize RTC
	RTC_Init();
	
	//Initialize LCD
	InitLCD();

	//Initialize keypad
	Init_kpm();
	
	//Initialize interrupt
	Init_Interrupt();

   //Initialize cgram
	BuildCGRAM(BulbONOFF,16);
	IODIR0|=1<<DEVICE_PIN;
	while(1)
	{
	  //Displaying date,time,day 
		Display_RTCInfo();
	//If eint is rised menu will display
		 if(flag==1)
		 {
		   //Displaying Menu
	    	Display_menu();
			flag=0;
		 }
		 //Displaying Cgram
		 CmdLCD(GOTO_CGRAM_START);
		 //Displaying Dev name
		 CmdLCD(GOTO_LINE2_POS0+11);
	     StrLCD("DEV:");
		 //status of on and off time
		 if(((IOPIN0>>ON_OFF_SW)&1)==0)
		   {
		   	  CmdLCD(CLEAR_LCD);
		      DisplayLEDONTime(on_hrs,on_min);
			  DisplayLEDOFFTime(off_hrs,off_min);
			  delay_s(2);
			  CmdLCD(CLEAR_LCD);
		   }
		 //for Device-Bulb ON
		 if((HOUR>=on_hrs) && (MIN>=on_min) && (HOUR<=off_hrs) && (MIN<off_min))
		 {
		  //set the device pin
		  IOSET0=1<<DEVICE_PIN;
		  CmdLCD(GOTO_LINE2_POS0+15);
		  CharLCD(1);
		  }
		 //for Device-Bulb OFF
		 else
		 {
		  IOCLR0=1<<DEVICE_PIN;
		  CmdLCD(GOTO_LINE2_POS0+15);
		  CharLCD(0);
	     }
	}
}

void Display_RTCInfo(void)
{
		 //For time display
		 GetRTCTimeInfo((s32*)&hour,(s32*)&minute,(s32*)&second);
		 DisplayRTCTime(hour,minute,second);
		 //For date display
		 GetRTCDateInfo((s32*)&date,(s32*)&month,(s32*)&year);
		 DisplayRTCDate(date,month,year);
		 //For day display
		 GetRTCDayInfo((s32*)&day);
		 DisplayRTCDay(DOW);
}
void Display_menu(void)
{
		//Clear the lcd and display Menu
		CmdLCD(CLEAR_LCD);
       	CmdLCD(GOTO_LINE1_POS0);
		StrLCD("1.Edit");
	    CmdLCD(GOTO_LINE1_POS0+8);
		StrLCD("3.Exit");
		CmdLCD(GOTO_LINE2_POS0);
		StrLCD("2.E.OnOff_Time");
		keyV=KeyScan();
		delay_ms(100);
		  switch(keyV)
		     {													                            
			    case  '1'://for edit Time
				          Edit_Time();
			              break;
			    case '2'://for edit ON_OFF Time
				         Edit_ON_OFF_Time();
			              break;
			    case '3'://for Exit 
				         CmdLCD(CLEAR_LCD);
				          break;
		    }
}
void Edit_Time(void)
{
 	while(1)
	{
		//clear the lcd and dispaly menu 
		 CmdLCD(CLEAR_LCD);
		 CmdLCD(GOTO_LINE1_POS0);
		 StrLCD("1.H 2.M 3.S 4.DY");
		 CmdLCD(GOTO_LINE2_POS0);
		 StrLCD("5.DA 6.M 7.Y 8.E");
		 keyV=KeyScan();
		 delay_ms(100);
		 switch(keyV)
		 {
		 			case '1'://for edit the hrs
				       start1:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Hrs(0-23)");
						     CmdLCD(GOTO_LINE2_POS0);
							 ReadNum(&num,(u32*)&lastkey);
							 if(num<24)
							 {
						     CmdLCD(CLEAR_LCD);
							 StrLCD("Updated");
							 delay_ms(200);
								HOUR=num;
							 }
							 else
							 {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start1;
							 }
							      break;
					case '2'://for edit the min
					   start2:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Min(0-59)");
						     CmdLCD(GOTO_LINE2_POS0);
						     ReadNum(&num,&lastkey);
					         if(num<=59)
							 {
							    CmdLCD(CLEAR_LCD);
							    StrLCD("Updated");
								delay_ms(200);
							      MIN=num;
							  }
							  else
							  {
							  	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start2;
							  }
			                        break;
					case '3'://for edit the sec
					   start3:CmdLCD(CLEAR_LCD);
					          CmdLCD(GOTO_LINE1_POS0);
					          StrLCD("Edit Sec(0-59");
						      CmdLCD(GOTO_LINE2_POS0);
					          ReadNum(&num,&lastkey);
					          if(num<=59)
							  {
							    CmdLCD(CLEAR_LCD);
							    StrLCD("Updated");
								delay_ms(200);
								   SEC=second;
							  }
							  else
							 {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start3;
							 }
							   		break;
					case '4'://for edit the day
					    start4:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Day(0-6)");
						     CmdLCD(GOTO_LINE2_POS0);
							 ReadNum(&num,&lastkey);
							  if(num<=6)
							  {
							     CmdLCD(CLEAR_LCD);
							     StrLCD("Updated");
								 delay_ms(200);
								  DOW=num;
							  }
							  else
							   {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start4;
							   }
								   break;
					case '5'://for edit the date
					   start5:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Date(1-31)");
						     CmdLCD(GOTO_LINE2_POS0);
						     ReadNum(&num,&lastkey);
					         if(num<=31)
							 {
							    CmdLCD(CLEAR_LCD);
							    StrLCD("Updated");
								delay_ms(200);
							       DOM=num;
						      }
						     else
							 {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start5;
							 }
									break;
					case '6'://for edit the mon
					   start6:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Mon(1-12)");
						      CmdLCD(GOTO_LINE2_POS0);
							 ReadNum(&num,&lastkey);
							 if(num<=12)
							 {
							    CmdLCD(CLEAR_LCD);
							    StrLCD("Updated");
								delay_ms(200);
								  MONTH=num;
							 }
							 else
							 {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start6;
							  }
									break;
					case '7'://for edit  the year
					    start7:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit year");
						     CmdLCD(GOTO_LINE2_POS0);
					         ReadNum(&num,&lastkey);
					         if(num<4095)
							 {
							    CmdLCD(CLEAR_LCD);
							    StrLCD("Updated");
								delay_ms(200);
								   YEAR=num;
							}
						      else
							 {
							 	CmdLCD(CLEAR_LCD);
								StrLCD("Invalid");
								delay_ms(200);
								goto start7;
							 }
									break;
					case '8'://for exit
					         CmdLCD(CLEAR_LCD);
					              return;
		 }
															    
	}
}
void Edit_ON_OFF_Time(void)
{
   //Display the edit on&off menu
   start1: CmdLCD(CLEAR_LCD);
	CmdLCD(GOTO_LINE1_POS0);
	StrLCD("1.E.OnTime");
	StrLCD("3.Exit");
	CmdLCD(GOTO_LINE2_POS0);
	StrLCD("2.E.OffTime");
	keyV=KeyScan();
    delay_ms(100);
	  switch(keyV)
	  {
	  		case '1':Edit_ON_Time();
			           goto start1;
			case '2':Edit_OFF_Time();
			           goto start1;
		    case '3':CmdLCD(CLEAR_LCD);
				          return;
	  }	
}
void Edit_ON_Time(void)
{
     
 	while(1)
	{
		 //Display ON menu
		 CmdLCD(CLEAR_LCD);
		 CmdLCD(GOTO_LINE1_POS0);
		 StrLCD("Edit ON Time");
		 CmdLCD(GOTO_LINE2_POS0);
		 StrLCD("1.H 2.M 3.E");
		 keyV=KeyScan();
		 delay_ms(100);
		 switch(keyV)
		 {

		 			case '1'://for edit hrs
					   label1:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Hrs(0-23)");
						     CmdLCD(GOTO_LINE2_POS0);
					         ReadNum(&num,&lastkey);
							 if(num<=23)
							 {
					              CmdLCD(CLEAR_LCD);
								  StrLCD("Updated");
								  delay_ms(200);
								  on_hrs=num;
							  }
								else
								{   CmdLCD(CLEAR_LCD);
								  StrLCD("Invalid");
								  delay_ms(200);
								  goto label1;
								  }
								  break;
				                 
					case '2'://for edit min
					         label2:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Min(0-59)");
					         CmdLCD(GOTO_LINE2_POS0);
						      ReadNum(&num,&lastkey);
							 if(num<=59)
							 {
					              CmdLCD(CLEAR_LCD);
								  StrLCD("Updated");
								  delay_ms(200);
								  on_min=num;
							  }
								 else
								 {  CmdLCD(CLEAR_LCD);
								  StrLCD("Invalid");
								  delay_ms(200);
								  goto label2; }
								  break;
					case '3'://for exit
					         CmdLCD(CLEAR_LCD);
					         return;
	    	}
	}					    		
}
void Edit_OFF_Time(void)
{
  	while(1)
	{
		//Display off time menu
		 CmdLCD(CLEAR_LCD);
		 CmdLCD(GOTO_LINE1_POS0);
		 StrLCD("Edit OFF Time");
		 CmdLCD(GOTO_LINE2_POS0);
		 StrLCD("1.H 2.M 3.E");
		 keyV=KeyScan();
		 delay_ms(100);
		 switch(keyV)
		 {
		 			case '1'://for edit hrs
				             label1:CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Hrs(0-23)");
					         CmdLCD(GOTO_LINE2_POS0);
					          ReadNum(&num,&lastkey);
							 if(num<=23)
							 {
					              CmdLCD(CLEAR_LCD);
								  StrLCD("Updated");
								  delay_ms(200);
								  off_hrs=num;
							  }
								 else{ CmdLCD(CLEAR_LCD);
								  StrLCD("Invalid");
								  delay_ms(200);
								  goto label1;}
								  break;
					case '2'://for edit min
					        label2: CmdLCD(CLEAR_LCD);
					         CmdLCD(GOTO_LINE1_POS0);
					         StrLCD("Edit Min(0-59)");
					         CmdLCD(GOTO_LINE2_POS0);
						      ReadNum(&num,&lastkey);
							 if(num<=59)
							 {
					              CmdLCD(CLEAR_LCD);
								  StrLCD("Updated");
								  delay_ms(200);
								  off_min=num;
							  }
								 else{  CmdLCD(CLEAR_LCD);
								  StrLCD("Invalid");
								  delay_ms(200);
								  goto label2;}
								  break;
					case '3'://for exit
					         CmdLCD(CLEAR_LCD);
					         return;
	    	}
	}					 
}
