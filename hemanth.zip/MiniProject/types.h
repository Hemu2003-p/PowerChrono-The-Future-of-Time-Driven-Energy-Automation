//types.h
typedef unsigned int u32;
typedef int s32;
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short int u16;
typedef signed short int s16;
typedef const unsigned char cu8; 
typedef const signed char cs8;
typedef float f32;
typedef double f64;

