//eint.h
void Init_Interrupt(void);
void eint0_isr(void) __irq;
void eint1_isr(void) __irq;
