//Pin_function.c
#include "pin_function_defines.h"
#include "pin_connect_block.h"
int main()
{
   cfgPortPinFunc(0,0,PIN_FUNC4);
   cfgPortPinFunc(0,0,PIN_FUNC3);
   cfgPortPinFunc(0,0,PIN_FUNC2);
   cfgPortPinFunc(0,0,PIN_FUNC1);
   cfgPortPinFunc(0,16,PIN_FUNC4);
   cfgPortPinFunc(0,20,PIN_FUNC3);
   cfgPortPinFunc(0,27,PIN_FUNC2);
   cfgPortPinFunc(0,30,PIN_FUNC1);
   while(1);
}
